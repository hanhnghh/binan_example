package com.musicdownloader.vimeodailymotiondownloader.view;

import android.widget.ImageView;

/**
 * Created by Hanh Nguyen on 7/10/2017.
 */

public interface VimeoVideoView {
    void loadPhoto(ImageView view, String url);
}
