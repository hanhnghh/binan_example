package com.musicdownloader.vimeodailymotiondownloader.di;

import javax.inject.Scope;

/**
 * Created by Hanh Nguyen on 7/7/2017.
 */
@Scope
public @interface PerActivity {
}
