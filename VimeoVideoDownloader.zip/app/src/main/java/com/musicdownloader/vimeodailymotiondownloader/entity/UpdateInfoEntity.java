package com.musicdownloader.vimeodailymotiondownloader.entity;

/**
 * Created by Hanh Nguyen on 7/7/2017.
 */

public class UpdateInfoEntity {
    /*"banner_ads": "ca-app-pub-1549215738778675/2073068549",
      "interstitial_ads": "ca-app-pub-1549215738778675/9596335341",
      "update": "false",
      "update_title": "Update de",
      "update_message": "Update nao",
      "update_cancelable": "true",
      "update_link": "https://play.google.com/store/apps/details?id=com.Slack"
    */

    public String banner_ads;
    public String interstitial_ads;
    public boolean update;
    public String update_title;
    public String update_message;
    public boolean update_cancelable;
    public String update_link;
}
